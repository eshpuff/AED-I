''' Descobrir o país '''
# pais= "JAPÃO"
# tentativa= input("Informe um país: ").upper()

# while tentativa != pais:
#     print("Errou! 😓")
#     tentativa= input("Informe um país: ").upper()

# print("Acertou 🤩. O país é "+tentativa)

''' Descobrir o país com 5 tentativas '''
pais= "BRASIL"
i= 1
tentativa= input("Informe um país: ").upper()

if (tentativa == pais):
    print("Acertou 🤩. O país é "+tentativa)

else:
    while tentativa != pais and i < 5:
        print("Errou! Foram ",i," tentativas.")
        tentativa= input("Informe um país: ").upper()
        i = i + 1

        if (tentativa == pais):
            print("Acertou 🤩. O país é "+tentativa)
        if i == 5:
            print("Acabaram suas tentativas.")
                                         