''' montar algoritmo onde se le a data e então diz se é valido ou não'''

dia= int(input("Insira o dia: "))
mes= int(input("Insira o mês: "))
ano= int(input("Insira o ano: "))
bi= ano%4

if mes > 12 or mes <1:
    print("Mes inválido.")

if dia > 31 or dia < 1:
    print("Dia inválido 1.")

else:
        if mes == 1 or mes == 3 or mes == 5 or mes == 7 or mes == 8 or mes == 10 or mes == 12:
            if dia > 31:
                print("Dia inválido 2.")
        if mes != 1 or mes != 3 or mes != 5 or mes != 7 or mes != 8 or mes != 10 or mes != 12:
            if dia > 30:
                print("Dia inválido 3.")
        if mes == 2 and dia > 29:
            print ("Dia inválido 4.")
        if (mes == 2 and bi != 0):
            if dia > 28:
                print("Dia Inválido.")
        else:
            print("Data válida.")