''' loop com contador '''
i =  1
while i <= 1000:
    print(i,str(" Eu amo AED1 😍."))
    i = i + 1